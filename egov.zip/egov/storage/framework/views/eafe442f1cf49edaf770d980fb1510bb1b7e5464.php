

<?php $__env->startSection('title', 'Data Warga'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<div class="row page-titles">
    <div class="col-md-5 col-8 align-self-center">
        <h3 class="text-themecolor">Dashboard</h3>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
        </ol>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
        </div>
    <?php endif; ?>
    <div class="card-body">
        <h4 class="card-title">Data Warga</h4>
        <h6 class="card-subtitle">Data warga desa maraacang</h6>
        <a href="<?php echo e(url('warga/create')); ?>" class="btn btn-primary"><i class="mdi mdi-account-plus"></i> Tambah warga</a>
        <div class="table-responsive m-t-40">
            <table id="myTable" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>NIK</th>
                        <th>Name</th>
                        <th>Tanggal Lahir</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $wargas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->nik); ?></td>
                        <td><?php echo e($item->nama); ?></td>
                        <td><?php echo e($item->tanggal_lahir); ?></td>
                        <td class="text-center">
                            <a href="<?php echo e(url('warga/edit/'.$item->nik )); ?>" class="btn btn-outline-warning btn-sm">
                                <i class="mdi mdi-account-card-details"></i>
                            </a>
                            <a href="<?php echo e(url('warga/edit/'.$item->nik )); ?>" class="btn btn-outline-secondary btn-sm">
                                <i class="mdi mdi-account-edit"></i>
                            </a>
                            <form action="<?php echo e(url('warga/'.$item->nik)); ?>" method="post" class="d-inline" onsubmit="return confirm('Yakin hapus data ?')">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-outline-danger btn-sm"><i class="mdi mdi-account-remove"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\egov\resources\views/pages/warga.blade.php ENDPATH**/ ?>