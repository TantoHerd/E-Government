@extends('main')

@section('title', 'Edit Warga')

@section('breadcrumbs')
<div class="row page-titles">
    <div class="col-md-5 col-8 align-self-center">
        <h3 class="text-themecolor">Dashboard</h3>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item active">@yield('title')</li>
        </ol>
    </div>
</div>
@endsection

@section('content')
<div class="row">
    <div class="col-lg-12">
        <div class="card card-outline-info">
            <div class="card-body">
                <form action="{{ url('warga/'.$warga->nik) }}" method="post">
                    @method('patch')
                    @csrf
                    <div class="form-body">
                        <h3 class="card-title">Edit Data Perorangan</h3>
                        <hr>
                        <div class="row p-t-20">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">NIK</label>
                                    <input type="text" name="nik" class="form-control @error('nik') is-invalid @enderror" value="{{ $warga->nik }}" autofocus>
                                    @error('nik')
                                    <div class="invalid-feedback">{{ $message }}</div> 
                                    @enderror
                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Nama Lengkap</label>
                                    <input type="text" name="nama" class="form-control @error('nama') is-invalid @enderror" value="{{ $warga->nama }}">
                                    @error('nama')
                                    <div class="invalid-feedback">{{ $message }}</div> 
                                    @enderror
                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Tempat Lahir</label>
                                    <input type="text" name="tempat_lahir" class="form-control @error('tempat_lahir') is-invalid @enderror" value="{{ $warga->tempat_lahir }}">
                                    @error('tempat_lahir')
                                    <div class="invalid-feedback">{{ $message }}</div> 
                                    @enderror
                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Tanggal Lahir</label>
                                    <input type="date" name="tanggal_lahir" class="form-control @error('tanggal_lahir') is-invalid @enderror" value="{{ $warga->tanggal_lahir }}" placeholder="hh/bb/tttt">
                                    @error('tanggal_lahir')
                                    <div class="invalid-feedback">{{ $message }}</div> 
                                    @enderror
                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group has-success">
                                    <label class="control-label">Kategori</label>
                                    <div class="form-group">
                                        <select class="form-control" value="{{ $warga->kategori }}" name="kategori" required>
                                            <option>Warga</option>
                                            <option>Lurah</option>
                                            <option>RW</option>
                                            <option>RT</option>
                                        </select>
                                    </div>
                                    @error('kategori')
                                    <div class="invalid-feedback">{{ $message }}</div> 
                                    @enderror
                                </div>
                            </div>
                            <!--/span-->
                            <div class="col-md-6">
                                <div class="form-group has-success">
                                    <label class="control-label">Jenis Kelamin</label>
                                    <div class="form-group">
                                        <select class="form-control" value="{{ $warga->jenis_kelamin }}" name="jenis_kelamin" required>
                                            <option>Laki-laki</option>
                                            <option>Perempuan</option>
                                        </select>
                                    </div>
                                    @error('jenis_kelamin')
                                    <div class="invalid-feedback">{{ $message }}</div> 
                                    @enderror
                                </div>
                            </div>
                            <!--/span-->
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Usia</label>
                                    <input type="text" name="usia" class="form-control @error('usia') is-invalid @enderror" value="{{ $warga->usia }}">
                                    @error('usia')
                                    <div class="invalid-feedback">{{ $message }}</div> 
                                    @enderror
                                </div>
                            </div>
                            <!--/span-->
                            <!--/span-->
                        </div>
                        <!--/row-->
                        <h3 class="box-title m-t-40">Alamat</h3>
                        <hr>
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="form-group">
                                    <label>Alamat Lengkap</label>
                                    <input type="text" name="alamat" class="form-control @error('usia') is-invalid @enderror" value="{{ $warga->alamat }}">
                                    @error('usia')
                                    <div class="invalid-feedback">{{ $message }}</div> 
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <h3 class="box-title m-t-40">Avatar</h3>
                        <hr>
                        <div class="row">
                            <div class="col-lg-6 col-md-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">Pilih file</h4>
                                        <label for="input-file-max-fs">Ukuran maksimal 2MB </label>
                                        <input type="file" value="{{ $warga->avatar }}" name="avatar" class="dropify" data-max-file-size="2M" />
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success"> <i class="fa fa-check"></i> Save</button>
                        <a href="{{ url('warga') }}" class="btn btn-inverse">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection