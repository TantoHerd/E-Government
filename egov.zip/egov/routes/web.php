<?php

use App\Http\Controllers\DashboardController;
use App\Http\Middleware\CekLogin;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'OtentikasiController@index')->name('login');
Route::post('login', 'OtentikasiController@login');

Route::group(['middleware' => 'auth'], function(){
    Route::get('dashboard', 'DashboardController@index');
    Route::get('warga', 'WargaController@index');
    Route::get('warga/create', 'WargaController@create');
    Route::post('warga', 'WargaController@store');
    Route::get('warga/edit/{nik}', 'WargaController@edit');
    Route::patch('warga/{nik}', 'WargaController@update');
    Route::delete('warga/{nik}', 'WargaController@delete');
    Route::get('logout', 'OtentikasiController@logout');
});