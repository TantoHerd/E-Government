<?php

namespace App\Http\Controllers;

use App\Warga;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class WargaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $wargas = Warga::all();
        return view('pages/warga', compact('wargas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pages/tambah_warga');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = new \App\User;
        $user->role = 'warga';
        $user->name = $request->nama;
        $user->email = $request->email;
        $user->password = bcrypt('123456');
        $user->remember_token = Str::random(50);
        $user->save();

        $request->validate([
            'nik' => 'required',
            'nama' => 'required|min:3',
            'tempat_lahir' => 'required',
            'tanggal_lahir' => 'required',
            'usia' => 'required'
        ], [
            'nik.required' => 'NIK tidak boleh kosong',
            'nama.required' => 'Nama minimal 6 karakter',
            'tempat_lahir.required' => 'Tempat Lahir tidak boleh kosong',
            'tanggal_lahir.required' => 'Tanggal Lahir tidak boleh kosong',
            'usia.required' => 'Usia tidak boleh kosong'
        ]);
        // return $request;
        $warga = new Warga;
        $warga->nik = $request->nik;
        $warga->user_id = $user->id;
        $warga->nama = $request->nama;
        $warga->tempat_lahir = $request->tempat_lahir;
        $warga->tanggal_lahir = $request->tanggal_lahir;
        $warga->email = $request->email;
        $warga->jenis_kelamin = $request->jenis_kelamin;
        $warga->usia = $request->usia;
        $warga->alamat = $request->alamat;
        $warga->avatar = $request->avatar;
        $warga->save();

        return redirect('warga')->with('status', 'Data warga berhasil ditambah');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Warga  $warga
     * @return \Illuminate\Http\Response
     */
    public function show(Warga $warga)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Warga  $warga
     * @return \Illuminate\Http\Response
     */
    public function edit($nik)
    {
        $warga = DB::table('warga')->where('nik', $nik)->first();
        return view('pages/edit', compact('warga'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Warga  $warga
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $nik)
    {
        DB::table('warga')->where('nik', $nik)
        ->update([
            'nik' => $request->nik,
            'nama' => $request->nama,
            'tempat_lahir' => $request->tempat_lahir,
            'tanggal_lahir' => $request->tanggal_lahir,
            'kategori' => $request->kategori,
            'jenis_kelamin' => $request->jenis_kelamin,
            'usia' => $request->usia,
            'alamat' => $request->alamat,
            'avatar' => $request->avatar
        ]);

        return redirect('warga')->with('status', 'Data warga berhasil diupdate');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Warga  $warga
     * @return \Illuminate\Http\Response
     */
    public function delete($nik)
    {
        DB::table('warga')->where('nik', $nik)->delete();
        return redirect('warga')->with('status', 'Data warga berhasil dihapus');
    }
}
