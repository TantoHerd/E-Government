<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Warga extends Model
{
    protected $table = 'warga';
    protected $fillable = ['nik', 'nama', 'email', 'user_id', 'tempat_lahir', 'tanggal_lahir', 'jenis_kelamin', 'usia', 'alamat', 'avatar'];
}
